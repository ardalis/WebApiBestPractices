﻿namespace ApiBestPractices.Endpoints.Endpoints.Authors;

public record AuthorListResult(int Id, string Name, string TwitterAlias);
