﻿using BackendData.Security;

namespace ApiBestPractices.Endpoints.Endpoints.Account;

public class TokenResponse
{
	public AccessToken AccessToken { get; set; }
}
