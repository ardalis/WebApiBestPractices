﻿namespace ApiBestPractices.Endpoints.Endpoints.Authors;

public class CreatedAuthorResult : CreateAuthorCommand
{
	public int Id { get; set; }
}
