﻿namespace BackendData.DataAccess.Config;

public class ConfigConstants
{
	public const int DEFAULT_NAME_LENGTH = 100;
	public const int DEFAULT_URI_LENGTH = 255;
}
