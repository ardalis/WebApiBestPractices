﻿namespace BackendData;

public abstract class BaseEntity
{
  public int Id { get; internal set; }
}
