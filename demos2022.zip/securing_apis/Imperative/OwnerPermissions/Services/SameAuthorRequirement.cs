﻿using Microsoft.AspNetCore.Authorization;

namespace OwnerPermissions.Services;

public class SameAuthorRequirement : IAuthorizationRequirement { }
