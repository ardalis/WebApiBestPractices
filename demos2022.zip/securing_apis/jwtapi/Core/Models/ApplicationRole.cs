﻿namespace JWTAPI.Core.Models;

public enum ApplicationRole
{
	Common = 1,
	Administrator = 2
}
