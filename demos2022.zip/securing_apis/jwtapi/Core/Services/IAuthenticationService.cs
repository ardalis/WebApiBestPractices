﻿using JWTAPI.Core.Services.Communication;

namespace JWTAPI.Core.Services;

public interface IAuthenticationService
{
	Task<TokenResponse> CreateAccessTokenAsync(string email, string password);
	Task<TokenResponse> RefreshTokenAsync(string refreshToken, string userEmail);
	void RevokeRefreshToken(string refreshToken, string userEmail);
}
